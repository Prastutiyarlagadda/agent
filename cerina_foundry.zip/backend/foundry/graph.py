from langgraph.graph import StateGraph, START, END
from langgraph.checkpoint.sqlite import SqliteSaver
from .state import CBTProtocolState
from .agents import draftsman_agent, safety_guardian_agent, clinical_critic_agent, empathy_coach_agent
from .supervisor import supervisor_node, human_gate

checkpointer = SqliteSaver.from_uri("sqlite:///cbt_foundry.sqlite")
builder = StateGraph(CBTProtocolState)

builder.add_node("supervisor", supervisor_node)
builder.add_node("draftsman", draftsman_agent)
builder.add_node("safety_guardian", safety_guardian_agent)
builder.add_node("clinical_critic", clinical_critic_agent)
builder.add_node("empathy_coach", empathy_coach_agent)
builder.add_node("human_gate", human_gate)

builder.add_edge(START, "supervisor")
builder.add_edge("draftsman", "supervisor")
builder.add_edge("safety_guardian", "supervisor")
builder.add_edge("clinical_critic", "supervisor")
builder.add_edge("empathy_coach", "supervisor")
builder.add_edge("human_gate", END)

graph = builder.compile(checkpointer=checkpointer)
