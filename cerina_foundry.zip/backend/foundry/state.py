from typing import List, Dict, Literal, Optional
from pydantic import BaseModel, Field

class AgentNote(BaseModel):
    agent: str
    iteration: int
    note: str

class DraftVersion(BaseModel):
    content: str
    safety_score: float = 0.0
    clinical_score: float = 0.0
    empathy_score: float = 0.0
    meta: Dict = Field(default_factory=dict)

class CBTProtocolState(BaseModel):
    user_intent: str
    current_draft: str = ""
    previous_drafts: List[DraftVersion] = Field(default_factory=list)
    safety_flags: List[str] = Field(default_factory=list)
    safety_score: float = 1.0
    clinical_score: float = 0.0
    empathy_score: float = 0.0
    iteration: int = 0
    status: Literal["drafting","needs_human","approved","rejected","done"] = "drafting"
    last_agent: Optional[str] = None
    agent_notes: List[AgentNote] = Field(default_factory=list)
    event_log: List[str] = Field(default_factory=list)
