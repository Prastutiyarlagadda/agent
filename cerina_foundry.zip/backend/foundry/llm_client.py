class LLMClient:
    async def generate(self, prompt: str, max_tokens: int = 512):
        return {"text": "[stubbed LLM response]", "score": 0.9}
