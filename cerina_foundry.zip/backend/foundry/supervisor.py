def supervisor_node(state):
    return "human_gate"

async def human_gate(state):
    state.status = "needs_human"
    return state
