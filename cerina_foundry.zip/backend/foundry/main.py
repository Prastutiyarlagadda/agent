# Placeholder server
from fastapi import FastAPI
app = FastAPI()
